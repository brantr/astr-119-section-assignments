#!/usr/bin/env python3

#this program will write
#Hello from William Ryan

print("Hello from William Ryan")